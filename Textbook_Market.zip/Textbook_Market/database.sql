-- CREATE TABLE Clients (
-- clientNo VARCHAR(4),
-- name VARCHAR(30),
-- sex VARCHAR(10),
-- age INTEGER,
-- email VARCHAR(50),
-- PRIMARY KEY (clientNo));


-- INSERT INTO Clients VALUES('C201','Kewon Song','Male','36','ksong@gmail.com');
-- INSERT INTO Clients VALUES('C202','Frank Mancione','Male','14','fmancione@hotmail.com');
-- INSERT INTO Clients VALUES('C203','Angela Peterkin','Female','66','angela@gmail.com');
-- INSERT INTO Clients VALUES('C204','Stephanie Johnson','Female','16','sjohnson@gmail.com');
-- INSERT INTO Clients VALUES('C205','Rafael Bah','Male','17','rbah@yahoo.com');
-- INSERT INTO Clients VALUES('C206','Leisa Aras','Female','49','laras@yahoo.com');
-- INSERT INTO Clients VALUES('C207','Robert Salsberry','Male','55','rsalsberry@hotmail.com');
-- INSERT INTO Clients VALUES('C208','Alfina Chanti','Female','24','achanti@hotmail.com');
-- INSERT INTO Clients VALUES('C209','Connie Profaci','Female','32','cprofaci@yahoo.com');
-- INSERT INTO Clients VALUES('C210','Steven Plac','Male','17','steven@yahoo.com');
-- INSERT INTO Clients VALUES('C211','Cindy Lyon','Female','20','cindy.lyon@hotmail.com');
-- INSERT INTO Clients VALUES('C212','Nicole Gary','Female','26','ngary@gmail.com');

CREATE TABLE Users (
userID VARCHAR(4),
name VARCHAR(30),
major VARCHAR(30),
email VARCHAR(50),
PRIMARY KEY (userID));

INSERT INTO Users VALUES('U01','Kewon Song','English','ksong@gmail.com');
INSERT INTO Users VALUES('U02','Frank Mancione','History','fmancione@hotmail.com');
INSERT INTO Users VALUES('U03','Angela Peterkin','Mathematics','angela@gmail.com');
INSERT INTO Users VALUES('U04','Stephanie Johnson','Biology','sjohnson@gmail.com');
INSERT INTO Users VALUES('U05','Rafael Bah','Chemistry','rbah@yahoo.com');
INSERT INTO Users VALUES('U06','Leisa Aras','Physics','laras@yahoo.com');
INSERT INTO Users VALUES('U07','Robert Salsberry','Spanish','rsalsberry@hotmail.com');
INSERT INTO Users VALUES('U08','Alfina Chanti','Political Science','achanti@hotmail.com');
INSERT INTO Users VALUES('U09','Connie Profaci','Computer Science','cprofaci@yahoo.com');
INSERT INTO Users VALUES('U10','Steven Plac','Computer Information Systems','steven@yahoo.com');
INSERT INTO Users VALUES('U11','Cindy Lyon','Art','cindy.lyon@hotmail.com');
INSERT INTO Users VALUES('U12','Nicole Gary','Music','ngary@gmail.com');

CREATE TABLE BooksForSale (
    bookNo INTEGER,
    ISBN BIGINT,
    title VARCHAR(30),
    author VARCHAR(30),
    edition INTEGER,
    course VARCHAR(7),
    price DECIMAL(5,2),
    userID VARCHAR(4),
    PRIMARY KEY (bookNo),
);

CREATE TABLE Requests (
    requestNo INTEGER,
    userID VARCHAR(4),
    title VARCHAR(30),
    author VARCHAR(30),
    edition INTEGER,
    course VARCHAR(7),
    PRIMARY KEY (requestNo)
);